// ─── CATALOG ──────────────────────────────────────────────────────────────────
import { useState } from 'react'
import { Modal, Confirm, Card, Btn, Field, Inp, Icon, EXP_CATS, fmt, today } from '../components/ui'

export function Catalog({ catalog, orders, db, toast }) {
  const [modal, setModal] = useState(null)
  const [confirm, setConfirm] = useState(null)
  const [form, setForm] = useState({})
  const [saving, setSaving] = useState(false)

  const openNew = () => { setForm({ name: '', price: '', cost: '', emoji: '🪑', description: '' }); setModal('new') }
  const openEdit = (c) => { setForm({ name: c.name, price: c.price, cost: c.cost, emoji: c.emoji || '🪑', description: c.description || '' }); setModal(c) }

  const save = async () => {
    setSaving(true)
    const row = { name: form.name, price: +form.price || 0, cost: +form.cost || 0, emoji: form.emoji, description: form.description || null }
    if (modal === 'new') {
      const { error } = await db.catalog.insert(row)
      if (!error) toast('Позиция добавлена ✓')
    } else {
      const { error } = await db.catalog.update(modal.id, row)
      if (!error) toast('Позиция обновлена ✓')
    }
    setSaving(false); setModal(null)
  }

  const del = async (id) => {
    await db.catalog.remove(id); setConfirm(null); toast('Позиция удалена')
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h2 style={{ margin: 0, fontSize: 20, color: '#fff', fontWeight: 800 }}>Каталог</h2>
        <Btn onClick={openNew}><Icon n="plus" size={14} />Добавить</Btn>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(155px, 1fr))', gap: 10 }}>
        {catalog.map(c => {
          const cnt = orders.filter(o => o.product === c.name).length
          const margin = c.price > 0 ? Math.round((c.price - c.cost) / c.price * 100) : 0
          return (
            <Card key={c.id}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>{c.emoji}</div>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#fff', marginBottom: 6, lineHeight: 1.3 }}>{c.name}</div>
              <div style={{ fontSize: 16, color: '#c9a96e', fontWeight: 800 }}>{fmt(c.price)}</div>
              <div style={{ fontSize: 11, color: '#555', marginTop: 2 }}>Себест: {fmt(c.cost)}</div>
              <div style={{ fontSize: 11, color: '#10b981', marginTop: 1 }}>Маржа: {margin}%</div>
              {c.description && <div style={{ fontSize: 11, color: '#444', marginTop: 4 }}>{c.description}</div>}
              <div style={{ fontSize: 11, color: '#444', marginTop: 5 }}>Продано: {cnt} шт</div>
              <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
                <Btn sm onClick={() => openEdit(c)} style={{ background: '#1e2028', color: '#999', flex: 1 }}><Icon n="edit" size={12} /></Btn>
                <Btn sm variant="red" onClick={() => setConfirm(c.id)}><Icon n="trash" size={12} /></Btn>
              </div>
            </Card>
          )
        })}
      </div>

      {confirm && <Confirm msg="Удалить позицию?" onYes={() => del(confirm)} onNo={() => setConfirm(null)} />}

      {modal && (
        <Modal title={modal === 'new' ? '➕ Новая позиция' : '✏️ Редактировать'} onClose={() => setModal(null)}>
          <div style={{ display: 'grid', gridTemplateColumns: '60px 1fr', gap: 10 }}>
            <Field label="Emoji"><Inp value={form.emoji} onChange={e => setForm(f => ({ ...f, emoji: e.target.value }))} style={{ fontSize: 24, textAlign: 'center' }} /></Field>
            <Field label="Название"><Inp value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Компьютерный стол" /></Field>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <Field label="Цена (сом)"><Inp type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} /></Field>
            <Field label="Себестоимость"><Inp type="number" value={form.cost} onChange={e => setForm(f => ({ ...f, cost: e.target.value }))} /></Field>
          </div>
          {form.price && form.cost && +form.price > 0 && (
            <div style={{ background: '#10b98110', border: '1px solid #10b98130', borderRadius: 10, padding: '10px 14px', marginBottom: 14, fontSize: 13 }}>
              Прибыль: <b style={{ color: '#10b981' }}>{fmt(+form.price - +form.cost)}</b> · Маржа: <b style={{ color: '#10b981' }}>{Math.round((+form.price - +form.cost) / +form.price * 100)}%</b>
            </div>
          )}
          <Field label="Описание"><Inp value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Краткое описание" /></Field>
          <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
            <Btn onClick={save} disabled={saving} style={{ flex: 1 }}><Icon n="save" size={14} />{saving ? 'Сохранение...' : 'Сохранить'}</Btn>
            <Btn variant="ghost" onClick={() => setModal(null)} style={{ background: '#1e2028', color: '#999' }}>Отмена</Btn>
          </div>
        </Modal>
      )}
    </div>
  )
}

// ─── FINANCE ──────────────────────────────────────────────────────────────────
export function Finance({ orders, expenses, db, toast }) {
  const [modal, setModal] = useState(null)
  const [confirm, setConfirm] = useState(null)
  const [form, setForm] = useState({})
  const [saving, setSaving] = useState(false)

  const revenue = orders.reduce((s, o) => s + (+o.price || 0), 0)
  const orderCosts = orders.reduce((s, o) => s + (+o.cost || 0), 0)
  const expTotal = expenses.reduce((s, e) => s + (+e.amount || 0), 0)
  const profit = revenue - orderCosts - expTotal
  const collected = orders.reduce((s, o) => s + (+o.prepaid || 0), 0)
  const pending = revenue - collected

  const catColor = { Материалы: '#3b82f6', Подрядчик: '#8b5cf6', Доставка: '#06b6d4', Зарплата: '#f59e0b', Реклама: '#e1306c', Другое: '#888' }

  const openNew = () => { setForm({ category: 'Материалы', amount: '', note: '', expense_date: today() }); setModal('new') }
  const openEdit = (e) => { setForm({ category: e.category, amount: e.amount, note: e.note || '', expense_date: e.expense_date }); setModal(e) }

  const saveExp = async () => {
    setSaving(true)
    const row = { category: form.category, amount: +form.amount || 0, note: form.note || null, expense_date: form.expense_date }
    if (modal === 'new') {
      await db.expenses.insert(row); toast('Расход добавлен ✓')
    } else {
      await db.expenses.update(modal.id, row); toast('Расход обновлён ✓')
    }
    setSaving(false); setModal(null)
  }

  const del = async (id) => { await db.expenses.remove(id); setConfirm(null); toast('Расход удалён') }

  return (
    <div>
      <h2 style={{ margin: '0 0 14px', fontSize: 20, color: '#fff', fontWeight: 800 }}>Финансы</h2>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
        {[
          { l: 'Выручка', v: revenue, c: '#c9a96e' },
          { l: 'Чистая прибыль', v: profit, c: profit >= 0 ? '#10b981' : '#ef4444' },
          { l: 'Получено', v: collected, c: '#3b82f6' },
          { l: 'Ожидается', v: pending, c: '#f59e0b' },
        ].map(s => (
          <Card key={s.l} accent={s.c}>
            <div style={{ fontSize: 11, color: '#555', marginBottom: 5 }}>{s.l}</div>
            <div style={{ fontSize: 18, fontWeight: 800, color: s.c }}>{fmt(s.v)}</div>
          </Card>
        ))}
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <div style={{ fontSize: 12, color: '#555', fontWeight: 700 }}>РАСХОДЫ <span style={{ color: '#ef4444' }}>−{fmt(expTotal)}</span></div>
        <Btn sm onClick={openNew}><Icon n="plus" size={12} />Добавить</Btn>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
        {expenses.map(e => {
          const color = catColor[e.category] || '#888'
          return (
            <Card key={e.id} accent={color}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <span style={{ background: color + '20', color, border: `1px solid ${color}40`, borderRadius: 6, padding: '2px 8px', fontSize: 11, fontWeight: 700 }}>{e.category}</span>
                  {e.note && <div style={{ fontSize: 12, color: '#666', marginTop: 4 }}>{e.note}</div>}
                  <div style={{ fontSize: 11, color: '#444', marginTop: 2 }}>📅 {e.expense_date}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: 15, color: '#ef4444', fontWeight: 700 }}>−{fmt(e.amount)}</div>
                  <div style={{ display: 'flex', gap: 6, marginTop: 8, justifyContent: 'flex-end' }}>
                    <Btn sm onClick={() => openEdit(e)} style={{ background: '#1e2028', color: '#999' }}><Icon n="edit" size={12} /></Btn>
                    <Btn sm variant="red" onClick={() => setConfirm(e.id)}><Icon n="trash" size={12} /></Btn>
                  </div>
                </div>
              </div>
            </Card>
          )
        })}
        {expenses.length === 0 && <div style={{ textAlign: 'center', color: '#444', padding: 24, fontSize: 13 }}>Расходов нет</div>}
      </div>

      <Card>
        <div style={{ fontSize: 11, color: '#555', marginBottom: 10, fontWeight: 700 }}>ЗАКАЗЫ — ДЕТАЛИЗАЦИЯ</div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12, minWidth: 480 }}>
            <thead>
              <tr>{['#', 'Товар', 'Цена', 'Себест.', 'Прибыль', 'Предоплата', 'Остаток'].map(h => (
                <th key={h} style={{ textAlign: 'left', padding: '6px 8px', color: '#444', fontWeight: 600, borderBottom: '1px solid #1e2028', whiteSpace: 'nowrap' }}>{h}</th>
              ))}</tr>
            </thead>
            <tbody>
              {orders.map(o => (
                <tr key={o.id} style={{ borderBottom: '1px solid #1a1c22' }}>
                  <td style={{ padding: '7px 8px', color: '#444' }}>{o.id}</td>
                  <td style={{ padding: '7px 8px', color: '#ddd', maxWidth: 100, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{o.product}</td>
                  <td style={{ padding: '7px 8px', color: '#c9a96e', fontWeight: 600 }}>{fmt(o.price)}</td>
                  <td style={{ padding: '7px 8px', color: '#ef4444' }}>{fmt(o.cost)}</td>
                  <td style={{ padding: '7px 8px', color: '#10b981' }}>{fmt((+o.price || 0) - (+o.cost || 0))}</td>
                  <td style={{ padding: '7px 8px', color: '#3b82f6' }}>{fmt(o.prepaid)}</td>
                  <td style={{ padding: '7px 8px', color: (+o.price - +o.prepaid) > 0 ? '#f59e0b' : '#444' }}>{fmt((+o.price || 0) - (+o.prepaid || 0))}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={2} style={{ padding: '8px', color: '#888', fontWeight: 700, borderTop: '1px solid #252830' }}>ИТОГО</td>
                <td style={{ padding: '8px', color: '#c9a96e', fontWeight: 700, borderTop: '1px solid #252830' }}>{fmt(revenue)}</td>
                <td style={{ padding: '8px', color: '#ef4444', fontWeight: 700, borderTop: '1px solid #252830' }}>{fmt(orderCosts)}</td>
                <td style={{ padding: '8px', color: '#10b981', fontWeight: 700, borderTop: '1px solid #252830' }}>{fmt(revenue - orderCosts)}</td>
                <td style={{ padding: '8px', color: '#3b82f6', fontWeight: 700, borderTop: '1px solid #252830' }}>{fmt(collected)}</td>
                <td style={{ padding: '8px', color: '#f59e0b', fontWeight: 700, borderTop: '1px solid #252830' }}>{fmt(pending)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </Card>

      {confirm && <Confirm msg="Удалить расход?" onYes={() => del(confirm)} onNo={() => setConfirm(null)} />}
      {modal && (
        <Modal title={modal === 'new' ? '➕ Новый расход' : '✏️ Расход'} onClose={() => setModal(null)}>
          <Field label="Категория">
            <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))} style={{ width: '100%', background: '#0e1016', border: '1px solid #252830', borderRadius: 10, padding: '11px 13px', color: '#fff', fontSize: 14, outline: 'none', boxSizing: 'border-box' }}>
              {EXP_CATS.map(c => <option key={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Сумма (сом)"><Inp type="number" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} /></Field>
          <Field label="Примечание"><Inp value={form.note} onChange={e => setForm(f => ({ ...f, note: e.target.value }))} placeholder="Описание" /></Field>
          <Field label="Дата"><Inp type="date" value={form.expense_date} onChange={e => setForm(f => ({ ...f, expense_date: e.target.value }))} /></Field>
          <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
            <Btn onClick={saveExp} disabled={saving} style={{ flex: 1 }}><Icon n="save" size={14} />{saving ? 'Сохранение...' : 'Сохранить'}</Btn>
            <Btn variant="ghost" onClick={() => setModal(null)} style={{ background: '#1e2028', color: '#999' }}>Отмена</Btn>
          </div>
        </Modal>
      )}
    </div>
  )
}

// ─── ANALYTICS ────────────────────────────────────────────────────────────────
import { SOURCES, STATUS_COLOR, STATUSES } from '../components/ui'

export function Analytics({ orders, clients, catalog }) {
  const srcCount = SOURCES.reduce((a, s) => { a[s] = orders.filter(o => o.source === s).length; return a }, {})
  const srcColors = { Instagram: '#e1306c', WhatsApp: '#25d366', Telegram: '#0088cc', Сайт: '#c9a96e', Другое: '#888' }

  const topProducts = catalog.map(c => ({
    name: c.name, emoji: c.emoji,
    count: orders.filter(o => o.product === c.name).length,
    revenue: orders.filter(o => o.product === c.name).reduce((s, o) => s + (+o.price || 0), 0),
  })).filter(x => x.count > 0).sort((a, b) => b.count - a.count)

  const maxCount = Math.max(1, ...topProducts.map(p => p.count))
  const completed = orders.filter(o => o.status === 'Завершён').length
  const convRate = orders.length > 0 ? Math.round(completed / orders.length * 100) : 0
  const avgCheck = orders.length > 0 ? Math.round(orders.reduce((s, o) => s + (+o.price || 0), 0) / orders.length) : 0
  const avgProfit = orders.length > 0 ? Math.round(orders.reduce((s, o) => s + ((+o.price - +o.cost) || 0), 0) / orders.length) : 0

  return (
    <div>
      <h2 style={{ margin: '0 0 14px', fontSize: 20, color: '#fff', fontWeight: 800 }}>Аналитика</h2>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 14 }}>
        {[
          { l: 'Средний чек', v: fmt(avgCheck), c: '#c9a96e' },
          { l: 'Сред. прибыль', v: fmt(avgProfit), c: '#10b981' },
          { l: 'Конверсия', v: convRate + '%', c: '#8b5cf6' },
        ].map(s => (
          <Card key={s.l} accent={s.c}>
            <div style={{ fontSize: 10, color: '#555', marginBottom: 4 }}>{s.l}</div>
            <div style={{ fontSize: 16, fontWeight: 800, color: s.c }}>{s.v}</div>
          </Card>
        ))}
      </div>

      <Card style={{ marginBottom: 12 }}>
        <div style={{ fontSize: 11, color: '#555', marginBottom: 12, fontWeight: 700 }}>ИСТОЧНИКИ</div>
        {SOURCES.filter(s => srcCount[s] > 0).map(s => {
          const pct = Math.round(srcCount[s] / orders.length * 100)
          return (
            <div key={s} style={{ marginBottom: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, fontSize: 13 }}>
                <span style={{ color: '#ddd' }}>{s}</span>
                <span style={{ color: srcColors[s] }}>{srcCount[s]} · {pct}%</span>
              </div>
              <div style={{ height: 7, background: '#0e1016', borderRadius: 4 }}>
                <div style={{ height: 7, background: srcColors[s], borderRadius: 4, width: pct + '%' }} />
              </div>
            </div>
          )
        })}
        {orders.length === 0 && <div style={{ color: '#444', fontSize: 13 }}>Нет данных</div>}
      </Card>

      <Card style={{ marginBottom: 12 }}>
        <div style={{ fontSize: 11, color: '#555', marginBottom: 12, fontWeight: 700 }}>ТОП ТОВАРОВ</div>
        {topProducts.map(p => (
          <div key={p.name} style={{ marginBottom: 10 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, fontSize: 13 }}>
              <span style={{ color: '#ddd' }}>{p.emoji} {p.name}</span>
              <span style={{ color: '#c9a96e' }}>{p.count} шт</span>
            </div>
            <div style={{ height: 7, background: '#0e1016', borderRadius: 4 }}>
              <div style={{ height: 7, background: 'linear-gradient(90deg,#c9a96e,#e8c98a)', borderRadius: 4, width: (p.count / maxCount * 100) + '%' }} />
            </div>
          </div>
        ))}
        {topProducts.length === 0 && <div style={{ color: '#444', fontSize: 13 }}>Нет данных</div>}
      </Card>

      <Card>
        <div style={{ fontSize: 11, color: '#555', marginBottom: 12, fontWeight: 700 }}>ЦЕЛЬ: 65 ЗАКАЗОВ / МЕС</div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontSize: 13 }}>
          <span style={{ color: '#ddd' }}>{orders.length} из 65</span>
          <span style={{ color: '#c9a96e' }}>{Math.round(Math.min(orders.length / 65, 1) * 100)}%</span>
        </div>
        <div style={{ height: 12, background: '#0e1016', borderRadius: 6 }}>
          <div style={{ height: 12, borderRadius: 6, background: 'linear-gradient(90deg,#c9a96e,#f59e0b)', width: Math.min(orders.length / 65 * 100, 100) + '%' }} />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 16 }}>
          {[
            { l: 'Завершено', v: completed },
            { l: 'В производстве', v: orders.filter(o => o.status === 'Производство').length },
            { l: 'На доставке', v: orders.filter(o => o.status === 'Доставка').length },
            { l: 'Всего клиентов', v: clients.length },
          ].map(s => (
            <div key={s.l} style={{ background: '#0e1016', borderRadius: 10, padding: '10px 12px' }}>
              <div style={{ fontSize: 10, color: '#444' }}>{s.l}</div>
              <div style={{ fontSize: 20, fontWeight: 800, color: '#fff', marginTop: 2 }}>{s.v}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
